#!/usr/bin/env python
# license removed for brevity
import rospy
from geometry_msgs.msg import PoseStamped, PoseWithCovarianceStamped, Pose, Point, Quaternion
from std_msgs.msg import Header
from threading import Thread

class Navigator():
    last_msg = None
    waiting = False
    temp_sub = None
    #pub = None
    def __init__(self):
        #self.pub = rospy.Publisher('/move_base/goal', PoseStamped, queue_size=1)    
        #self.request = False
        self.waiting = False
        self.last_msg = None
        self.temp_sub = None
        #s = rospy.Service('publish_goal', PublishGoal, handle_publish_goal)
    def update_message(self):
        print("Set up subscriber")
        rospy.init_node('position_handler_test')
        self.temp_sub = rospy.Subscriber("amcl_pose", PoseWithCovarianceStamped, self.only_one_pose)
    def only_one_pose(self, data):
        print("Got message")
        self.last_msg = data
        self.waiting = False
        self.temp_sub.unregister()
        self.temp_sub = None
    def you_can_put_service_handlers_here_maybe(self, req):
        pass
    
    def do_stuff(self):
        while True:
            raw_input("Hit ENTER to display pose: ")
            self.update_message()
            self.waiting = True
            while (self.waiting):
                pass
            print(self.last_msg)                

if __name__ == '__main__':
    try:
        n = Navigator()
        n.do_stuff()
    except rospy.ROSInterruptException:
        pass
