#!/usr/bin/env python
# license removed for brevity
import rospy
from geometry_msgs.msg import PoseStamped, PoseWithCovarianceStamped, Pose, Point, Quaternion
from std_msgs.msg import Header
from threading import Thread

class Navigator():
    pub = None
    sub = None
    last_msg = None
    def __init__(self):
        self.pub = rospy.Publisher('/move_base/goal', PoseStamped, queue_size=1)    
        self.waiting = False
        self.last_msg = None
        self.temp_sub = None
        self.sub = rospy.Subscriber("amcl_pose", PoseWithCovarianceStamped, self.callback)
        #s = rospy.Service('publish_goal', PublishGoal, handle_publish_goal)
    def callback(self, data):
        self.last_msg = data
    def display_current_position(self):
        print(self.last_msg)
    def publish_position_xy(self, x, y):
        print("Publishing point:",x,y)
        #Don't know if these values matter
        h = Header(seq=1, stamp = rospy.Time.now(), frame_id=str(x)+"_"+str(y))
        p = Point(float(x), float(y), 0.0)
        q = Quaternion(0.0, 0.0, 0.0, 1.0)
        to_pub = PoseStamped(header = h, pose = Pose(position = p, orientation = q))
        print(to_pub)
        self.pub.publish(to_put)
        
if __name__ == '__main__':
    try:
        rospy.init_node("web_navigation_test")
        n = Navigator()
        while True:
            print("Options:")
            print("\t(D)isplay robots current position")
            print("\t(S)ave robots current position")
            print("\t(R)ead a saved position")
            print("\t(O)utput a saved position to the robot")
            print("\t(P)ublish a position from console to the robot")
            print("\t(D)elete a saved position")
            print("\t(L)ist the saved positions")
            inp = raw_input("Choice:")
            if(inp.upper() == "D"):
                n.display_current_position()
            elif(inp.upper() == "P"):
                try:
                    x = input("X pos:")
                    y = input("Y pos:")
                    n.publish_position_xy(x, y)
                except:
                    print("input is annoying")
            else:
                print("Unknown choice!") 
    except rospy.ROSInterruptException:
        pass
